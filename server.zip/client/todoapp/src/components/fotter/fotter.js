import React from 'react'
import "./fotter.css"
const fotter = () => {
  return (
    <div className='container-fluid p-3 d-flex justify-content-center align-items-center text-dark fotter'>
        <h4>Todo</h4> &nbsp; <p className='m-0'>&copy;THECODEMASTER</p>
        </div>
  )
}

export default fotter