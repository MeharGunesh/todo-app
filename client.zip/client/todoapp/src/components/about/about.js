import React from 'react';
import "./about.css";

const about = () => {
    return (
        <div className='about d-flex justify-content-center align-items-center'>
            <div className='container'>
                <div className='d-flex'>
                <h1>About Me</h1>

                </div>
           
            <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus eum, officiis consequatur totam ullam eveniet minus earum minima, sequi dolorum, commodi suscipit quam hic. Excepturi iusto voluptates nihil! Mollitia quia molestias quisquam veniam sed nihil minus. Velit fugiat pariatur,
                 laudantium quasi magni nemo exercitationem porro, tenetur voluptate est et beatae explicabo. Nobis aperiam atque, rem quas perspiciatis, fugiat quae molestiae odit nulla officia vero unde quod! Neque perferendis molestiae, officia corporis voluptas maiores, ipsa repellendus minima accusamus
                  repudiandae quibusdam tempore delectus facere, dolorem quo omnis aperiam minus voluptate nostrum nobis beatae. Doloribus deleniti enim vitae, ipsam reprehenderit inventore ex cupiditate architecto repellat explicabo voluptas ipsa recusandae? Corrupti eos soluta hic in quaerat blanditiis odit,
                   quae asperiores minima enim dolorem eius sunt, vitae neque cumque nesciunt ipsa praesentium? Dolorem nulla fuga aliquid repellendus aliquam tempora adipisci veniam sequi explicabo, corporis nesciunt. Accusantium mollitia dolor quos ad modi consequatur eius obcaecati aperiam?
                   <br/>
                   Lorem ipsum dolor, sit amet consectetur adipisicing elit. Possimus eum, officiis consequatur totam ullam eveniet minus earum minima, sequi dolorum, commodi suscipit quam hic. Excepturi iusto voluptates nihil! Mollitia quia molestias quisquam veniam sed nihil minus. Velit fugiat pariatur,
                 laudantium quasi magni nemo exercitationem porro, tenetur voluptate est et beatae explicabo. Nobis aperiam atque, rem quas perspiciatis, fugiat quae molestiae odit nulla officia vero unde quod! Neque perferendis molestiae, officia corporis voluptas maiores, ipsa repellendus minima accusamus
                  repudiandae quibusdam tempore delectus facere, dolorem quo omnis aperiam minus voluptate nostrum nobis beatae. Doloribus deleniti enim vitae, ipsam reprehenderit inventore ex cupiditate architecto repellat explicabo voluptas ipsa recusandae? Corrupti eos soluta hic in quaerat blanditiis odit,
                   quae asperiores minima enim dolorem eius sunt, vitae neque cumque nesciunt ipsa praesentium? Dolorem nulla fuga aliquid repellendus aliquam tempora adipisci veniam sequi explicabo, corporis nesciunt. Accusantium mollitia dolor quos ad modi consequatur eius obcaecati aperiam?
                   </p>
            </div>

        </div>
    )
}

export default about